# ÉTUDE 06 — Banking Analytics | Khadija Machghoul

## Jeu de données pédagogique
Portefeuille de 250 prêts fictifs ; encours total 18 200 000 MAD ; 7 crédits en impayé (>0 jour de retard), soit **2,8 % des dossiers**. Ce taux est exprimé en **nombre de prêts**, et non en proportion monétaire des encours impayés. Un prêt en retard n'est pas nécessairement un prêt en défaut au sens réglementaire.

## Power BI Desktop — procédure
1. **Obtenir les données > Texte/CSV** : importer `portefeuille_credits.csv` en UTF-8, séparateur **point-virgule**.
2. Dans Power Query : types de données : texte pour ID/segment/produit/région/statut/classe, date pour Octroi, nombre entier pour Durée et Jours retard, décimal pour Encours, Taux annuel, PD, LGD. Vérifier le séparateur décimal `.` en sélectionnant la locale Anglais (États-Unis) si nécessaire.
3. Renommer la table importée **Portefeuille** ; créer les mesures du fichier `MESURES_DAX.txt`.
4. Page **01 Vue exécutive** : cartes Encours Total, Nombre Credits, Taux Impayes Dossiers, Encours Impayes, PAR 30, PAR 90, Perte Attendue Indicative. Segment et Région en segments (slicers).
5. Graphiques : barres Encours par Segment, barres crédits impayés par Région, histogramme des jours de retard ; tableau détaillé avec mise en forme conditionnelle sur PD.
6. Page **02 Early warning** : analyser les crédits en retard, >30 et >90 jours ; comparer la répartition du risque par classe A–D.
7. Page **03 Portefeuille** : matrice Segment × Région (encours, nombre, taux impayés, PAR30).

## Limites importantes
- Données 100 % synthétiques, y compris les variables PD et LGD.
- `EAD = Encours` est une approximation pédagogique ; ne pas traiter la perte attendue comme provision IFRS 9 ni comme calcul réglementaire Bâle.
- Les résultats ne doivent être attribués à aucune institution financière réelle.
- Le livrable Excel est fonctionnel ; le `.pbix` doit être assemblé dans Power BI Desktop, qui n'est pas disponible ici.
