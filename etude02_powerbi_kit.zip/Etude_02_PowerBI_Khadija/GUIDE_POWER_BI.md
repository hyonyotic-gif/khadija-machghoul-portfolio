# ÉTUDE 02 — Performance financière | Vue exécutive

**Auteur du portfolio : Khadija Machghoul**  
**Entreprise fictive : NOVA Group Maroc**  
**Période : janvier 2024–septembre 2026**  
**Nature : données synthétiques, aucune donnée client réelle.**

## Objectif métier
Créer un tableau de bord décisionnel permettant à la direction financière de suivre le chiffre d’affaires, le respect du budget, la rentabilité opérationnelle, l’évolution mensuelle et les contributions par activité et région.

## Importation Power BI Desktop
1. Accueil → Obtenir des données → Texte/CSV : importer `data/Fait_Finance.csv`, `data/Dim_Date.csv`, `data/Dim_Activite.csv` et `data/Dim_Region.csv` (encodage UTF-8).
2. Power Query : définir `Date` en Date (pas Date/Heure), `Annee` et `Mois` en Entier, montants en Nombre entier (ou décimal fixe), catégories en Texte. Vérifier qu'aucun montant n'est converti en texte.
3. Modèle : créer `Dim_Date[Date] (1)` → `Fait_Finance[Date] (*)`, `Dim_Activite[BusinessUnit] (1)` → `Fait_Finance[BusinessUnit] (*)`, `Dim_Region[Region] (1)` → `Fait_Finance[Region] (*)`. Filtre à sens unique vers la table de faits, relations actives. Marquer Dim_Date comme table de dates (attention : la table mensuelle n'est **pas** une table calendaire continue ; pour les mesures DATEADD et TOTALYTD ci-dessous, construire plutôt une table date journalière comme indiqué).
4. **Recommandé pour un vrai modèle BI :** créer `Calendrier = CALENDAR(DATE(2024,1,1),DATE(2026,12,31))` et ajouter Année, numéro de mois, mois abrégé et trimestre. Relier `Calendrier[Date]` à `Fait_Finance[Date]` ; marquer Calendrier comme table de dates. Les mesures DAX utilisent déjà `Calendrier[Date]`. Utiliser cette table pour les segments temporels et l'intelligence temporelle. Ne pas connecter Dim_Date en parallèle.
5. Modélisation → Nouvelle mesure : créer les mesures dans `Mesures_DAX.txt` ; importer `theme_powerbi.json` via Affichage → Thèmes → Parcourir.
6. Page 16:9, fond `#0B1420`, cartes KPI, courbe mensuelle, barres par activité, barres par région et tableau Budget/Réel. Segments Année, Business Unit, Région.

## Pages recommandées
- **01 Vue exécutive :** CA réel, écart budget %, EBITDA, marge EBITDA, CA mensuel réel vs budget, mix BU, régions et tableau des écarts.
- **02 Rentabilité :** marge brute / EBITDA / EBIT par BU, waterfall CA→EBIT, tendances des marges.
- **03 Budget & écarts :** analyse des écarts MAD / %, responsables de variance, drill-through activité / région.

## Contrôles qualités indispensables
- Aucune relation many-to-many ; dates et dimensions sans doublons.
- CA = somme des contributions BU = somme des contributions régions.
- EBITDA = CA – coûts des ventes – OPEX ; EBIT = EBITDA – dotations.
- Variation % = écart / budget, pas écart / réel.
- 2026 comprend uniquement janvier à septembre : une comparaison brute de l’année 2026 contre 2025 entière est trompeuse. Utiliser une comparaison YTD alignée ou les mêmes mois.
- Les créances clients sont un **stock** et ne doivent pas être sommées sur plusieurs mois pour un indicateur de clôture.
- Les chiffres présentés sont fictifs : ne pas les faire passer pour des performances professionnelles réelles.

## Aperçu
Ouvrir `dashboard_demo.html` : rendu web interactif autonome avec filtres Année, Activité et Région, destiné à présenter le projet dans le portfolio. Ce n'est **pas** un export Power BI .pbix.
